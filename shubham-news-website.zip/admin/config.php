<?php
$con = mysqli_connect("localhost","root","", "news-cms") or dir('connection fail');
?>